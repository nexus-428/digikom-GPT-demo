sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/Dialog",
    "sap/m/Button", 
    "sap/m/Text",
    "sap/m/Input"  
],
  
    function (Controller, JSONModel, Dialog, Button, Text, Input) 
    {
        "use strict";
        
        return Controller.extend("oth.ui5.pizzablue.controller.Overview", {
            onInit: function () 
            {
                var oModel = new JSONModel(this.prepareData());
                this.getView().setModel(oModel);
                this.subtotal = 0;
                this.getView().byId("Trashcan").setVisible(false);
            },

            onBackgroundImageLoaded: function (event)
            {
                let screenWidth = sap.ui.Device.media.getCurrentRange(sap.ui.Device.media.RANGESETS.SAP_STANDARD).to + 260;
                this.byId("BackgroundImage").setWidth(`${screenWidth}px`);                
            },

            onIconTabSelected: function (event)
            {
                switch (event.getParameter("selectedKey")) 
                {
                    case "home":
                        this.getView().byId("CardHome").setVisible(true);
                        this.getView().byId("CardKontak").setVisible(false);
                        this.getView().byId("CardOperatingHours").setVisible(true);
                        this.getView().byId("CardMenu").setVisible(false);
                        this.getView().byId("CardShoppingCart").setVisible(false);
                        break;
                    case "contact":
                        this.getView().byId("CardHome").setVisible(false);
                        this.getView().byId("CardKontak").setVisible(true);
                        this.getView().byId("CardOperatingHours").setVisible(true);
                        this.getView().byId("CardMenu").setVisible(false);
                        this.getView().byId("CardShoppingCart").setVisible(false);
                        break;                   
                    default:
                        this.getView().byId("CardHome").setVisible(false);
                        this.getView().byId("CardKontak").setVisible(false);
                        this.getView().byId("CardOperatingHours").setVisible(false);
                        this.getView().byId("CardMenu").setVisible(true);
                        this.getView().byId("CardShoppingCart").setVisible(true);
                        break;
                }
            },

            onShoppingCartPress: function (event)
            {
                this.getView().byId("CardHome").setVisible(false);
                this.getView().byId("CardKontak").setVisible(false);
                this.getView().byId("CardOperatingHours").setVisible(false);
                this.getView().byId("CardMenu").setVisible(true);
                this.getView().byId("CardShoppingCart").setVisible(true);
            },

            onTrashcanPress: function (event)
            {
                this.getView().byId("TextPizzas").setText(""),
                this.getView().byId("TextPrices").setText(""),
                this.getView().byId("TextSubtotal").setText("0.00 EUR");
                this.getView().byId("TextGrandtotal").setText("0.00 EUR");
                this.getView().byId("FBSelectedPizzas").setVisible(false);
                this.getView().byId("Trashcan").setVisible(false);
            },

            onPress: function (event)
            {
                let selectedPizza = this.getView().getModel().getProperty(event.getSource().getBindingContext().getPath());
                this.selectedPizza = selectedPizza;

                if (!this.oAddPizzaDialog) {
                    this.oAddPizzaDialog = new Dialog({
                        type: "Message",
                        title: this.selectedPizza.PizzaName,
                        content: [new Input({id:"InputPizzaQuantity", width: "20px"}).addStyleClass("sapUiTinyMarginEnd"),
                                  new Button({icon: "sap-icon://add", type: "Success", press: () => {
                                    let inputPizzaQuantity = sap.ui.getCore().byId("InputPizzaQuantity");
                                    inputPizzaQuantity.setValue(Number(inputPizzaQuantity.getValue()) + 1);
                                  }}).addStyleClass("sapUiTinyMarginBegin"),
                                  new Button({icon: "sap-icon://less", type: "Negative", press: () => {
                                    let inputPizzaQuantity = sap.ui.getCore().byId("InputPizzaQuantity");
                                    if(Number(inputPizzaQuantity.getValue()) > 0)
                                    {
                                        inputPizzaQuantity.setValue(Number(inputPizzaQuantity.getValue()) - 1);
                                    }
                                  }}).addStyleClass("sapUiTinyMarginBegin")
                        ],
                        beginButton: new Button({
                            type: "Emphasized",
                            text: "Bestätigen",
                            press: function () 
                            {
                                debugger;
                                let pizzaText = this.getView().byId("TextPizzas"),
                                    priceText = this.getView().byId("TextPrices"),
                                    subtotalText   = this.getView().byId("TextSubtotal"),
                                    grandTotalText = this.getView().byId("TextGrandtotal"),
                                    inputPizzaQuantity = sap.ui.getCore().byId("InputPizzaQuantity");                               
                                    this.getView().byId("Trashcan").setVisible(true);

                                if(Number(inputPizzaQuantity.getValue()) > 0 && Number(inputPizzaQuantity.getValue()) === 1)
                                {
                                    pizzaText.setText(pizzaText.getText() + "\n" + this.selectedPizza.PizzaName);
                                    priceText.setText(priceText.getText() + "\n" + this.selectedPizza.Price);
                                    
                                    this.subtotal += this.selectedPizza.Price;
                                    this.getView().byId("FBSelectedPizzas").setVisible(true);
                                }
                                else if (Number(inputPizzaQuantity.getValue()) > 0 && Number(inputPizzaQuantity.getValue()) > 1)
                                {
                                    pizzaText.setText(pizzaText.getText() + "\n" + this.selectedPizza.PizzaName + " x " + Number(inputPizzaQuantity.getValue()));    
                                    priceText.setText(priceText.getText() + "\n" + this.selectedPizza.Price * Number(inputPizzaQuantity.getValue()));
                                    this.subtotal += (this.selectedPizza.Price * Number(inputPizzaQuantity.getValue()));
                                    this.getView().byId("FBSelectedPizzas").setVisible(true);
                                }

                                subtotalText.setText((Math.round(this.subtotal * 100) / 100).toFixed(2) + " EUR");
                                grandTotalText.setText((Math.round((this.subtotal + 3.00) * 100) / 100).toFixed(2) + " EUR");

                                inputPizzaQuantity.setValue("");
                                this.oAddPizzaDialog.close();
                            }.bind(this)
                        }),
                        endButton: new Button({
                            text: "Abbrechen",
                            press: function () 
                            {
                                this.oAddPizzaDialog.close();
                            }.bind(this)
                        })
                    });
                }
                this.oAddPizzaDialog.setTitle(this.selectedPizza.PizzaName);
                this.oAddPizzaDialog.open();
            },

            prepareData: function ()
            {

                let pizzas = this.getView().getModel("myData").getProperty("/Pizzas");
                var currentDate = new Date();   
                var currentMonth = currentDate.getMonth()+1;  
                var currentYear = currentDate.getFullYear();
                var currentDay = currentDate.getDate();                
                
                pizzas.forEach(Value => {
                    if (Value.DisplayPrice > 10 && Value.endofdeal.substring(6,10) >= currentYear)  {
                        if (Value.endofdeal.substring(3,5) > currentMonth) {
                                var oldPrice = Value.DisplayPrice;
                                var newPrice = Value.DisplayPrice - 2;
                                Value.DisplayPrice = "<span class='strike'>"+oldPrice+"</span> <span class='boldRedFont'>"+newPrice+"</span>";
                                Value.Price = newPrice;
                            } 
                        else if (Value.endofdeal.substring(3,5) = currentMonth){
                            if (Value.endofdeal.substring(0,2) >= currentDay) {
                                Value.DisplayPrice = "<span class='strike'>"+oldPrice+"</span> <span class='boldRedFont'>"+newPrice+"</span>"; 
                                Value.Price = newPrice;
                            }
                        }
                    }
                });

                return pizzas;
            },
            
            onOrder: function (event) 
            {
                let oView = this.getView();
                if(oView.byId("InputStreet").getValue() === "" || oView.byId("InputHouseNumber").getValue() === "" || oView.byId("InputPostalCode").getValue() === "" || oView.byId("InputCity").getValue() === "")
                {                
                    if (!this.oErrorMessageDialog) {
                        this.oErrorMessageDialog = new Dialog({
                            type: "Message",
                            title: "Error",
                            state: "Error",
                            content: new Text({ text: "Bitte ergänze deine Lieferardresse" }),
                            beginButton: new Button({
                                type: "Emphasized",
                                text: "Verstanden",
                                press: function () {
                                    this.oErrorMessageDialog.close();
                                }.bind(this)
                            })
                        });
                    }
        
                    this.oErrorMessageDialog.open();                    
                }
                else
                {
                    if (!this.oSuccessMessageDialog) {
                        this.oSuccessMessageDialog = new Dialog({
                            type: "Message",
                            title: "Vielen Dank",
                            state: "Success",
                            content: new Text({ text: "Deine Bestellung ist auf dem Weg zu dir" }),
                            beginButton: new Button({
                                type: "Emphasized",
                                text: "OK",
                                press: function () {
                                    this.oSuccessMessageDialog.close();
                                }.bind(this)
                            })
                        });
                    }
        
                    this.oSuccessMessageDialog.open();                       
                }
            }
        });
    });
